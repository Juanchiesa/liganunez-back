package io.swagger.api;

import io.swagger.model.HttpResponse;
import io.swagger.model.User;
import io.swagger.model.UserLoginHttpResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-06-30T19:42:06.417708714Z[GMT]")
@RestController
public class UserApiController implements UserApi {

    private static final Logger log = LoggerFactory.getLogger(UserApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public UserApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<HttpResponse> checkUserExistence(@Parameter(in = ParameterIn.HEADER, description = "Email ingresado" ,required=true,schema=@Schema()) @RequestHeader(value="email", required=true) String email) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<HttpResponse>(objectMapper.readValue("{\n  \"opCode\" : \"404\",\n  \"errors\" : [ {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  }, {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  } ]\n}", HttpResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<HttpResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<HttpResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<HttpResponse> createUser(@Parameter(in = ParameterIn.DEFAULT, description = "Información del usuario (debe enviarse sin accessKey)", required=true, schema=@Schema()) @Valid @RequestBody User body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<HttpResponse>(objectMapper.readValue("{\n  \"opCode\" : \"404\",\n  \"errors\" : [ {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  }, {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  } ]\n}", HttpResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<HttpResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<HttpResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<UserLoginHttpResponse> loginUser(@Parameter(in = ParameterIn.HEADER, description = "Correo electrónico ingresado" ,required=true,schema=@Schema()) @RequestHeader(value="email", required=true) String email,@Parameter(in = ParameterIn.HEADER, description = "Contraseña ingresada" ,required=true,schema=@Schema()) @RequestHeader(value="password", required=true) String password) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<UserLoginHttpResponse>(objectMapper.readValue("{\n  \"data\" : {\n    \"permissionLevel\" : 1,\n    \"address\" : \"Corrientes 800\",\n    \"accessKey\" : \"943012\",\n    \"name\" : \"Juan Perez\",\n    \"age\" : 32,\n    \"email\" : \"example@gmail.com\"\n  },\n  \"token\" : \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c\"\n}", UserLoginHttpResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<UserLoginHttpResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<UserLoginHttpResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<HttpResponse> requestUserPasswordUpdate(@Parameter(in = ParameterIn.HEADER, description = "" ,required=true,schema=@Schema()) @RequestHeader(value="userEmail", required=true) String userEmail) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<HttpResponse>(objectMapper.readValue("{\n  \"opCode\" : \"404\",\n  \"errors\" : [ {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  }, {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  } ]\n}", HttpResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<HttpResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<HttpResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<HttpResponse> updateUserPassword(@Parameter(in = ParameterIn.HEADER, description = "Código generado previamente" ,required=true,schema=@Schema()) @RequestHeader(value="requestCode", required=true) String requestCode) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<HttpResponse>(objectMapper.readValue("{\n  \"opCode\" : \"404\",\n  \"errors\" : [ {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  }, {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  } ]\n}", HttpResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<HttpResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<HttpResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

}
