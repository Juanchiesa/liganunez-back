package io.swagger.api;

import io.swagger.model.GetPicturesHttpResponse;
import io.swagger.model.HttpResponse;
import io.swagger.model.Picture;
import io.swagger.model.UploadPicturesHttpResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import javax.validation.constraints.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-07-05T19:15:05.066485954Z[GMT]")
@RestController
public class PictureApiController implements PictureApi {

    private static final Logger log = LoggerFactory.getLogger(PictureApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;

    @org.springframework.beans.factory.annotation.Autowired
    public PictureApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<HttpResponse> deletePicture(@Parameter(in = ParameterIn.PATH, description = "ID del torneo al que corresponde la imagen", required=true, schema=@Schema()) @PathVariable("tournamentId") String tournamentId,@Parameter(in = ParameterIn.PATH, description = "ID de la imagen", required=true, schema=@Schema()) @PathVariable("id") String id,@Parameter(in = ParameterIn.HEADER, description = "Token de autenticación del usuario" ,schema=@Schema()) @RequestHeader(value="token", required=false) String token) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<HttpResponse>(objectMapper.readValue("{\n  \"opCode\" : \"404\",\n  \"errors\" : [ {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  }, {\n    \"code\" : \"P01\",\n    \"description\" : \"Error interno\"\n  } ]\n}", HttpResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<HttpResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<HttpResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<GetPicturesHttpResponse> getPictures(@Parameter(in = ParameterIn.PATH, description = "", required=true, schema=@Schema()) @PathVariable("tournamentId") String tournamentId,@NotNull @Parameter(in = ParameterIn.QUERY, description = "" ,required=true,schema=@Schema()) @Valid @RequestParam(value = "pageNumber", required = true) Integer pageNumber) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<GetPicturesHttpResponse>(objectMapper.readValue("{\n  \"data\" : [ {\n    \"date\" : \"15/06/2023\",\n    \"file\" : \"bh5aLyZALN4othXL2mByHo1aZA5ts5k/uw/sc7DBngGY......\",\n    \"tournamentId\" : \"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\",\n    \"id\" : \"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\",\n    \"place\" : \"La Plata\"\n  }, {\n    \"date\" : \"15/06/2023\",\n    \"file\" : \"bh5aLyZALN4othXL2mByHo1aZA5ts5k/uw/sc7DBngGY......\",\n    \"tournamentId\" : \"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\",\n    \"id\" : \"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\",\n    \"place\" : \"La Plata\"\n  } ]\n}", GetPicturesHttpResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<GetPicturesHttpResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<GetPicturesHttpResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<UploadPicturesHttpResponse> uploadPictures(@Parameter(in = ParameterIn.HEADER, description = "Token de autenticación del usuario" ,schema=@Schema()) @RequestHeader(value="token", required=false) String token,@Parameter(in = ParameterIn.DEFAULT, description = "Información de las imágenes", schema=@Schema()) @Valid @RequestBody List<Picture> body) {
        String accept = request.getHeader("Accept");
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<UploadPicturesHttpResponse>(objectMapper.readValue("{\n  \"data\" : [ {\n    \"id\" : \"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\",\n    \"status\" : \"201\"\n  }, {\n    \"id\" : \"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx\",\n    \"status\" : \"201\"\n  } ]\n}", UploadPicturesHttpResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<UploadPicturesHttpResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<UploadPicturesHttpResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

}
