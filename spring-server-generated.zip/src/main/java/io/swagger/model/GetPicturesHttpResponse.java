package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Error;
import io.swagger.model.HttpResponse;
import io.swagger.model.Picture;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * GetPicturesHttpResponse
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-07-05T19:15:05.066485954Z[GMT]")


public class GetPicturesHttpResponse extends HttpResponse  {
  @JsonProperty("data")
  @Valid
  private List<Picture> data = null;

  public GetPicturesHttpResponse data(List<Picture> data) {
    this.data = data;
    return this;
  }

  public GetPicturesHttpResponse addDataItem(Picture dataItem) {
    if (this.data == null) {
      this.data = new ArrayList<Picture>();
    }
    this.data.add(dataItem);
    return this;
  }

  /**
   * Get data
   * @return data
   **/
  @Schema(description = "")
      @Valid
    public List<Picture> getData() {
    return data;
  }

  public void setData(List<Picture> data) {
    this.data = data;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GetPicturesHttpResponse getPicturesHttpResponse = (GetPicturesHttpResponse) o;
    return Objects.equals(this.data, getPicturesHttpResponse.data) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(data, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GetPicturesHttpResponse {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
