package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.core.io.Resource;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * PictureUploadBody
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2023-08-24T19:23:30.945376521Z[GMT]")


public class PictureUploadBody   {
  @JsonProperty("place")
  private String place = null;

  @JsonProperty("date")
  private String date = null;

  @JsonProperty("tournamentId")
  private String tournamentId = null;

  @JsonProperty("files")
  @Valid
  private List<Resource> files = null;

  public PictureUploadBody place(String place) {
    this.place = place;
    return this;
  }

  /**
   * Get place
   * @return place
   **/
  @Schema(example = "Palermo", description = "")
  
    public String getPlace() {
    return place;
  }

  public void setPlace(String place) {
    this.place = place;
  }

  public PictureUploadBody date(String date) {
    this.date = date;
    return this;
  }

  /**
   * Get date
   * @return date
   **/
  @Schema(example = "2023-07-06", description = "")
  
    public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public PictureUploadBody tournamentId(String tournamentId) {
    this.tournamentId = tournamentId;
    return this;
  }

  /**
   * Get tournamentId
   * @return tournamentId
   **/
  @Schema(example = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx", description = "")
  
    public String getTournamentId() {
    return tournamentId;
  }

  public void setTournamentId(String tournamentId) {
    this.tournamentId = tournamentId;
  }

  public PictureUploadBody files(List<Resource> files) {
    this.files = files;
    return this;
  }

  public PictureUploadBody addFilesItem(Resource filesItem) {
    if (this.files == null) {
      this.files = new ArrayList<Resource>();
    }
    this.files.add(filesItem);
    return this;
  }

  /**
   * Get files
   * @return files
   **/
  @Schema(description = "")
      @Valid
    public List<Resource> getFiles() {
    return files;
  }

  public void setFiles(List<Resource> files) {
    this.files = files;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PictureUploadBody pictureUploadBody = (PictureUploadBody) o;
    return Objects.equals(this.place, pictureUploadBody.place) &&
        Objects.equals(this.date, pictureUploadBody.date) &&
        Objects.equals(this.tournamentId, pictureUploadBody.tournamentId) &&
        Objects.equals(this.files, pictureUploadBody.files);
  }

  @Override
  public int hashCode() {
    return Objects.hash(place, date, tournamentId, files);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PictureUploadBody {\n");
    
    sb.append("    place: ").append(toIndentedString(place)).append("\n");
    sb.append("    date: ").append(toIndentedString(date)).append("\n");
    sb.append("    tournamentId: ").append(toIndentedString(tournamentId)).append("\n");
    sb.append("    files: ").append(toIndentedString(files)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
